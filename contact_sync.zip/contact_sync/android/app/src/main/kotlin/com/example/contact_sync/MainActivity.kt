package com.example.contact_sync

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
